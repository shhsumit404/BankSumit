<!DOCTYPE html>
<html>
<head>
	<title>Unsubscribed</title>
	<style>
		h1 {
			text-align: center;
		}
		body {
			background-color: #34495e;
			color: white;
		}
		button {
			margin-left: 420px;
		}
	</style>
</head>
<body>
<br><br>
	<h1>Sorry to see you go!</h1>
	<br><br><br>

	<a href="index.php">
		<button>
			Go back to Homepage
		</button>
	</a>

	<?php
	include("DBConnection.php");
	$query = "DELETE FROM news";
	$result = mysqli_query($db,$query);
	?>

</body>
</html>