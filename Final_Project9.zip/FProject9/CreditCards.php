<!DOCTYPE html>
<html>
<head>
	<title>Credit Cards</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">

    <style >
    	.Credit{
    		width: 900px;
    		height: 335px;
    		margin: auto;
    	}
    	input:hover {
    		background-color: #d35400;
    	}
    	table,td,th {
    		border: 1px solid;
    		text-align: center;
    	}
    </style>
</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
	<div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



      <header class="site-navbar site-navbar-target" role="banner">

        <div class="container">
          <div class="row align-items-center position-relative">

            <div class="col-lg-4">
              <nav class="site-navigation text-right ml-auto " role="navigation">
                <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                  <li><a href="index.php" class="nav-link">Home</a></li>
                  <li><a href="about.php" class="nav-link">About</a></li>
                  <li><a href="careers.php" class="nav-link">Careers</a></li>
                </ul>
              </nav>
            </div>
            <div class="col-lg-4 text-center">
              <div class="site-logo">
                <a href="index.php">Bank of Universe</a>
              </div>


              <div class="ml-auto toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-white"><span class="icon-menu h3 text-white"></span></a></div>
            </div>
            <div class="col-lg-4">
              <nav class="site-navigation text-left mr-auto " role="navigation">
                <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                  <li class="active"><a href="CreditCards.php" class="nav-link">Cards</a></li>
                  <li><a href="slogin.php" class="nav-link">Sign In</a></li>
                  <li><a href="contact.php" class="nav-link">Contact</a></li>
                </ul>
              </nav>
            </div>
            

          </div>
        </div>

      </header>

    <div class="ftco-blocks-cover-1">
      <div class="ftco-cover-1 overlay" style="background-image: url('images/Credit3.jpg')">
        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 text-center">
              <h1>Amazing Credit Cards with</h1>
              <h1>Amazing offer</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <br><br>
    <div class="Credit card list">
 	
    	<table>
    		<tr>
    			<th>Cards</th>
    			<th>Details</th>
    			<th>Action</th>
    		</tr>
    		<tr>
    			<td><img src="images/Credit1.jpg" style="width: 150px;height: 150px;">Cash Back</td>
    			<td>
    				<h6 style="color: #c0392b;">Reward Rate</h6>
    				1% - 3% <br>
    				Cash Back <br>
    				Welcome Bonus <br>
    				$150<i style="color: red;">*</i> <br>
    				No Annual Fee
    			</td>
    			<td>
    				<form action="CardApp.php" method="POST">
    					<input type="submit" name="apply" value="Apply" style="background-color: #16a085;color: white;">
    				</form>
    			</td>
    		</tr>
    		<tr>
    			<td>&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/Credit4.png" style="width: 130px;height: 100px;">&nbsp;&nbsp;Secured Card</td>
    			<td>
    				<h6 style="color: #c0392b;">Reward Rate</h6>
    				Min Deposit <br>
    				$200 <br>
    				Refundable <br>
    				Annual Fee: $36
    			</td>
    			<td>
    				<form action="CardApp.php" method="POST">
    					<input type="submit" name="apply" value="Apply" style="background-color: #16a085;color: white;">
    				</form>
    			</td>
    		</tr>
    	</table>

    </div>
    <br><br>

     <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-7">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>Far far away behind the word galaxies,far from the Milkyway galaxies and stars, there is a Bank of Universe.</p>
              </div>
              <div class="col-md-4 ml-auto">
                <h2 class="footer-heading mb-4">Features</h2>
                <ul class="list-unstyled">
                  <li><a href="about.php">About Us</a></li>
                  <li><a href="#">Acknowledgement</a></li>
                  <li><a href="#">Terms of Service</a></li>
                  <li><a href="#">Privacy</a></li>
                  <li><a href="contact.php">Contact Us</a></li>
                </ul>
              </div>

            </div>
          </div>

          <div class="col-md-4 ml-auto">

            <div class="mb-5">
              <h2 class="footer-heading mb-4">Subscribe to Newsletter</h2>
              <form action="Subscribe.php" method="post" class="footer-suscribe-form">
                <div class="input-group mb-3">
                  <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2" name="newsteller">
                  <div class="input-group-append">
                    <input class="btn btn-primary text-white" type="submit" id="button-addon2" value="Subscribe">
                  </div>
                </div>
            </div>


            <h2 class="footer-heading mb-4">Follow Us</h2>
            <a href="#about-section" class="smoothscroll pl-0 pr-3"><span class="icon-facebook"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </form>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
              <p>
            
            Copyright &copy;2019 All rights reserved By Sumit and Lian
            </p>
            </div>
          </div>

        </div>
      </div>
    </footer>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>

</body>
</html>