<!DOCTYPE html>
<html>
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
    <style >
    	button:hover {
    		background-color: navy;
    	}
    </style>
</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

	<div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



      <header class="site-navbar site-navbar-target" role="banner">

        <div class="container">
          <div class="row align-items-center position-relative">

            <div class="col-lg-4">
              <nav class="site-navigation text-right ml-auto " role="navigation">
                <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                  <li><a href="index.php" class="nav-link">Home</a></li>
                  <li><a href="about.php" class="nav-link">About</a></li>
                  <li class="active"><a href="careers.php" class="nav-link">Careers</a></li>
                </ul>
              </nav>
            </div>
            <div class="col-lg-4 text-center">
              <div class="site-logo">
                <a href="index.php">Bank of Universe</a>
              </div>


              <div class="ml-auto toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-white"><span class="icon-menu h3 text-white"></span></a></div>
            </div>
            <div class="col-lg-4">
              <nav class="site-navigation text-left mr-auto " role="navigation">
                <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                  <li><a href="CreditCards.php" class="nav-link">Cards</a></li>
                  <li><a href="blog.html" class="nav-link">Sign In</a></li>
                  <li><a href="contact.php" class="nav-link">Contact</a></li>
                </ul>
              </nav>
            </div>
            

          </div>
        </div>

      </header>

    <div class="ftco-blocks-cover-1">
      <div class="ftco-cover-1 overlay" style="background-image: url('images/Network.jpg');">
        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 text-center">
              <h2 style="color: white;">Network Engineer</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <br><br>
    <div class="description">
    	<h3 style="text-align: center;">Duties</h3>
    	<ul>
<li>Contribute to the design and enhancement of the universal backbone and datacenter infrastructures</li>
<li>Average networking tools to identify and mitigate network anomalies.</li>
<li>Analyze application data and traffic flow data to identify and improve on sub-optimal network behaviors.</li>
<li>Participate in developing policies, procedures and technical reports associated with operating and maintaining the global network.</li>
<li>Guide and assist deployment engineers in the implementation of new topologies and services.</li>
<li>Provide technical guidance and support to junior engineers in interpreting and reacting to network events</li>
    	</ul>

    	<br><br>
    	<h3 style="text-align: center;">Requirements</h3>
    	<ul>
<li>Bachelor’s degree in computer science or related field ( must graduate from accredited institution)</li>
<li>Strong understanding of network fundamentals in universal scale.</li>
<li>Familiarity with service provider implementations.</li>
<li>Experience with backbone and edge routing policy , engineering, and operation in a multi-transit, multi-peer environment</li>
<li>Experience in network automation and programing languages</li>
<li>Capable of mentoring junior-level network engineers in all aspects of network design, operations and deployment</li>
<li>Must speak, read, and write Universal common language.</li>
    	</ul>
    </div><br><br>

    <a href="#" class="button">
    	<button style="margin-left: 430px;background-color: #e74c3c;color: white;width: 150px;">Apply Now</button>
    </a><br><br>
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-7">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>Far far away behind the word galaxies,far from the Milkyway galaxies and stars, there is a Bank of Universe.</p>
              </div>
              <div class="col-md-4 ml-auto">
                <h2 class="footer-heading mb-4">Features</h2>
                <ul class="list-unstyled">
                  <li><a href="about.php">About Us</a></li>
                  <li><a href="#">Acknowledgement</a></li>
                  <li><a href="#">Terms of Service</a></li>
                  <li><a href="#">Privacy</a></li>
                  <li><a href="contact.php">Contact Us</a></li>
                </ul>
              </div>

            </div>
          </div>

          <div class="col-md-4 ml-auto">

            <div class="mb-5">
              <h2 class="footer-heading mb-4">Subscribe to Newsletter</h2>
              <form action="Subscribe.php" method="post" class="footer-suscribe-form">
                <div class="input-group mb-3">
                  <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2" name="newsteller">
                  <div class="input-group-append">
                    <input class="btn btn-primary text-white" type="submit" id="button-addon2" value="Subscribe">
                  </div>
                </div>
            </div>


            <h2 class="footer-heading mb-4">Follow Us</h2>
            <a href="#about-section" class="smoothscroll pl-0 pr-3"><span class="icon-facebook"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </form>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
              <p>
            
            Copyright &copy;2019 All rights reserved By Sumit and Lian
            </p>
            </div>
          </div>

        </div>
      </div>
    </footer>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>


</body>
</html>