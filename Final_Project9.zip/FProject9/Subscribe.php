<!DOCTYPE html>
<html>
<head>
	<title>Thank you</title>
	<style>
		body{
			background-color: #34495e;
			color: white;
		}
		div {
			width: 400px;
			height: 300px;
			background-color: #16a085;
			margin: auto;
			margin-top: 70px;
		}
		h1 {
			text-align: center;
		}
		p {
			text-align: center;
		}
		form {
			text-align: center;
		}
		input {
			background-color: #c0392b;
			color: white;
		}
		button{
			text-align: center;
			margin-left: 125px;
		}
	</style>
</head>
<body>

	<script >
		alert("Thank you");
	</script>

	<div>
		<h1>Thank You</h1>
		<br>
		<p>Now you will get the updates and news on time</p>
		<br><br>

		<form action="Unsubscribe.php" method="GET">
			<input type="submit" name="unsubscribe" value="Unsubscribe"><br>
		</form>
		<br><br>
		<a href="index.php">
			<button>
				Go Back to Homepage
			</button>
		</a>
	</div>

	<?php
	include("DBConnection.php");
	$news = $_POST['newsteller'];

    $query = "insert into news(Email) values('$news')";
    $result = mysqli_query($db, $query);
	?>

</body>
</html>